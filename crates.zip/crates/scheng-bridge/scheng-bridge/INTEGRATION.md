# scheng-bridge — Integration Guide

A WebSocket bridge between the scheng engine and visual frontend editors.

---

## What this adds to your workspace

```
scheng/
  crates/
    scheng-bridge/        ← new crate (this folder)
      src/
        lib.rs            public API
        protocol.rs       all JSON message types (ClientMessage / EngineMessage)
        graph_manager.rs  instrument layer: owns graph, NodeProps, FrameCtx
        server.rs         async WebSocket server (tokio + tungstenite)
        main.rs           standalone binary entry point
      scheng-editor.html  visual node editor (open in any browser)
      Cargo.toml
      INTEGRATION.md      ← you are here
```

---

## Quick start

### 1. Add the crate to your workspace

In your root `Cargo.toml`:

```toml
[workspace]
members = [
  "crates/scheng-core",
  "crates/scheng-graph",
  "crates/scheng-runtime",
  "crates/scheng-runtime-glow",
  # ...existing crates...
  "crates/scheng-bridge",   # ← add this
]
```

### 2. Run the bridge

```bash
# standalone binary
cargo run -p scheng-bridge

# or with custom address
SCHENG_BRIDGE_ADDR=0.0.0.0:7777 cargo run -p scheng-bridge

# or embed in your existing instrument binary (see §Embedding below)
```

### 3. Open the editor

Open `scheng-editor.html` in your browser (no server needed — it's a single file),
then click **connect**. The editor auto-hydrates from the engine's current state.

---

## Protocol reference

All messages are UTF-8 JSON. The `action` field routes inbound commands;
the `event` field identifies outbound messages.

### Inbound (frontend → engine)

| action | required fields | description |
|---|---|---|
| `add_node` | `id`, `kind`, `label` | Add a node. `position` is optional (UI only). |
| `remove_node` | `id` | Remove node and all attached edges. |
| `connect` | `from_node`, `from_port`, `to_node`, `to_port` | Wire two ports. |
| `disconnect` | `from_node`, `from_port`, `to_node`, `to_port` | Remove an edge. |
| `set_shader` | `node_id`, `glsl` | Replace GLSL source. Takes effect on next frame. |
| `set_param` | `node_id`, `param`, `value` | Update a single NodeProps value. |
| `set_params` | `node_id`, `params` | Batch update NodeProps. |
| `compile` | — | Validate topology and build execution plan. Required after structural changes. |
| `get_state` | — | Request a full state snapshot. |
| `advance_frame` | `width`, `height`, `time`, `frame` | Drive the engine forward one frame. |
| `move_node` | `id`, `position` | Update UI position only (not forwarded to engine). |

### Outbound (engine → frontend)

| event | key fields | description |
|---|---|---|
| `state` | `nodes[]`, `edges[]`, `compiled` | Full snapshot. Sent on connect and after compile. |
| `node_added` | NodeDescriptor | Echoed after `add_node`. |
| `node_removed` | `id` | Echoed after `remove_node`. |
| `edge_added` | EdgeDescriptor | Echoed after `connect`. |
| `edge_removed` | port fields | Echoed after `disconnect`. |
| `compiled` | `node_count`, `edge_count` | Compilation succeeded. |
| `shader_updated` | `node_id` | Shader source replaced. |
| `param_updated` | `node_id`, `param`, `value` | Single param changed. |
| `frame_executed` | `frame`, `time`, `elapsed_ms` | Frame completed. |
| `error` | `message`, `context?` | Command rejected or engine error. |
| `ok` | `ack` | Generic acknowledgement. |

**All connected clients receive all broadcast events** — multiple browser
windows, tools, or OSC adapters can observe the same engine simultaneously.

---

## Wiring to the real engine

`graph_manager.rs` contains clearly marked stubs. Each one is a single
comment block you replace with real engine calls.

### 1. Add dependencies in `Cargo.toml`

```toml
[dependencies]
scheng-graph        = { path = "../scheng-graph" }
scheng-runtime      = { path = "../scheng-runtime" }
scheng-runtime-glow = { path = "../scheng-runtime-glow" }
# keep the rest (tokio, serde, etc.)
```

### 2. `compile()` in `graph_manager.rs`

```rust
// Replace this block in GraphManager::compile():

let mut graph = scheng_graph::Graph::new();
for (id, desc) in &inner.nodes {
    graph.add_node(id, desc.kind.into())?;
}
for edge in &inner.edges {
    graph.connect(&edge.from_node, &edge.from_port, &edge.to_node, &edge.to_port)?;
}
let plan = graph.compile()?;
inner.execution_plan = Some(plan);
```

Add the field to `Inner`:
```rust
execution_plan: Option<scheng_graph::ExecutionPlan>,
```

### 3. `advance_frame()` in `graph_manager.rs`

```rust
// Replace the stub in GraphManager::advance_frame():

let plan = inner.execution_plan.as_ref()
    .ok_or(BridgeError::NotCompiled)?;

let ctx = scheng_runtime::FrameCtx { width, height, time, frame };

let t0 = std::time::Instant::now();
inner.runtime
    .execute_plan_outputs(plan, &ctx, &inner.node_props)
    .map_err(|e| BridgeError::Engine(e.to_string()))?;
let elapsed_ms = t0.elapsed().as_secs_f32() * 1000.0;
```

Add to `Inner`:
```rust
runtime: scheng_runtime_glow::GlowRuntime,
node_props: scheng_runtime::NodePropsMap,
```

### 4. NodeProps sync

After every `set_param` / `set_shader`, write the new value into
`inner.node_props` so the runtime picks it up on the next frame:

```rust
// in set_param():
if let Some(props) = inner.node_props.get_mut(&node_id) {
    props.set(param, value.into());
}
```

### 5. NodeKind conversion

Add `From<NodeKind> for scheng_graph::NodeKind`:

```rust
impl From<crate::protocol::NodeKind> for scheng_graph::NodeKind {
    fn from(k: crate::protocol::NodeKind) -> Self {
        match k {
            protocol::NodeKind::Source     => scheng_graph::NodeKind::Source,
            protocol::NodeKind::ShaderPass => scheng_graph::NodeKind::ShaderPass,
            protocol::NodeKind::Mixer      => scheng_graph::NodeKind::Mixer,
            protocol::NodeKind::Output     => scheng_graph::NodeKind::Output,
        }
    }
}
```

---

## Embedding in an existing instrument binary

If you already have a binary that sets up the GL context and runs the render
loop, you can spawn the bridge as a background task instead:

```rust
// In your main instrument binary:
use scheng_bridge::BridgeServer;

#[tokio::main]
async fn main() {
    let bridge = BridgeServer::new("127.0.0.1:7777".parse().unwrap());
    let manager = bridge.manager.clone();  // share with your render loop

    // Spawn bridge in background
    tokio::spawn(async move { bridge.run().await.unwrap(); });

    // Your existing render loop — call manager.advance_frame() each tick
    loop {
        let elapsed_ms = manager.advance_frame(1920, 1080, get_time(), frame_num).unwrap();
        // ... swap buffers, vsync, etc.
    }
}
```

---

## Architecture reminder

```
scheng-editor.html  (browser)
        │  JSON / WebSocket
  ┌─────▼──────────────────┐
  │     server.rs           │  tokio WebSocket, broadcast fan-out
  └─────┬──────────────────┘
        │
  ┌─────▼──────────────────┐
  │  graph_manager.rs       │  instrument layer
  │  owns: graph, NodeProps │  (stubs → real engine calls)
  └─────┬──────────────────┘
        │
  scheng-graph  ·  scheng-runtime  ·  scheng-runtime-glow
```

**Design contract (from SDK docs):**
- The bridge never reaches into engine internals — it calls public SDK surface only.
- NodeProps is owned by `GraphManager` (the instrument layer), read-only to runtime.
- The engine does not own time — `FrameCtx` is supplied per frame by the frontend via `advance_frame`.
- Topology changes invalidate the compiled plan; the bridge tracks this with `compiled: false`.

---

## Security note

By default the server binds to `127.0.0.1` (loopback only). To expose it
on a network (e.g., for a tablet control surface), set:

```bash
SCHENG_BRIDGE_ADDR=0.0.0.0:7777 cargo run -p scheng-bridge
```

Add auth/TLS if you expose this outside localhost.
