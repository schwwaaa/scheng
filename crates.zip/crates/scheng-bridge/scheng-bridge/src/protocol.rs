/// scheng-bridge protocol
///
/// All messages between the visual frontend and the scheng engine
/// pass through this module as JSON-serialized envelopes.
///
/// Design principle: the bridge never interprets execution semantics.
/// It translates JSON commands into engine calls and broadcasts state back.
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

// ---------------------------------------------------------------------------
// Inbound — frontend → engine
// ---------------------------------------------------------------------------

/// Every message sent from the frontend arrives as one of these variants.
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(tag = "action", rename_all = "snake_case")]
pub enum ClientMessage {
    // ── Graph topology ──────────────────────────────────────────────────────

    /// Add a new node to the graph.
    AddNode {
        /// Caller-supplied stable identifier shown in the UI.
        id: String,
        /// Node kind: "source", "shader_pass", "mixer", "output"
        kind: NodeKind,
        /// Human-readable label shown in the canvas.
        label: String,
        /// Initial position for the UI (not used by engine, echoed back).
        position: Option<Position>,
    },

    /// Remove a node and all of its connections.
    RemoveNode { id: String },

    /// Connect an output port of one node to an input port of another.
    Connect {
        from_node: String,
        from_port: String,
        to_node: String,
        to_port: String,
    },

    /// Disconnect a specific edge.
    Disconnect {
        from_node: String,
        from_port: String,
        to_node: String,
        to_port: String,
    },

    // ── NodeProps / parameters ───────────────────────────────────────────────

    /// Set (or replace) the GLSL fragment shader source for a node.
    SetShader { node_id: String, glsl: String },

    /// Set a single uniform/parameter on a node.
    SetParam {
        node_id: String,
        param: String,
        value: ParamValue,
    },

    /// Set multiple parameters on a node in one shot.
    SetParams {
        node_id: String,
        params: HashMap<String, ParamValue>,
    },

    // ── Graph lifecycle ──────────────────────────────────────────────────────

    /// Recompile the current graph topology.
    /// Topology changes (add/remove/connect) require this before the next frame.
    Compile,

    /// Request a full state snapshot (sent back as `EngineMessage::State`).
    GetState,

    // ── Transport / FrameCtx ─────────────────────────────────────────────────

    /// Caller owns time. Advance the engine by providing the next FrameCtx.
    AdvanceFrame {
        width: u32,
        height: u32,
        time: f32,
        frame: u64,
    },

    /// Move a node's canvas position (UI only, echoed back).
    MoveNode { id: String, position: Position },
}

// ---------------------------------------------------------------------------
// Outbound — engine → frontend
// ---------------------------------------------------------------------------

/// Every message sent from the bridge to connected frontend clients.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "event", rename_all = "snake_case")]
pub enum EngineMessage {
    /// Acknowledgement for a successful command.
    Ok { ack: String },

    /// A command was rejected or the engine returned an error.
    Error { message: String, context: Option<String> },

    /// Emitted after `Compile` completes successfully.
    Compiled { node_count: usize, edge_count: usize },

    /// Full graph + props snapshot (response to `GetState` or after compile).
    State(GraphState),

    /// A single node was added.
    NodeAdded(NodeDescriptor),

    /// A node was removed.
    NodeRemoved { id: String },

    /// An edge was added.
    EdgeAdded(EdgeDescriptor),

    /// An edge was removed.
    EdgeRemoved {
        from_node: String,
        from_port: String,
        to_node: String,
        to_port: String,
    },

    /// A node's shader was updated.
    ShaderUpdated { node_id: String },

    /// A parameter value was updated.
    ParamUpdated {
        node_id: String,
        param: String,
        value: ParamValue,
    },

    /// Frame was evaluated (basic perf telemetry).
    FrameExecuted {
        frame: u64,
        time: f32,
        /// Wall-clock ms spent in execute_plan (simulated here; wire to real timing in engine).
        elapsed_ms: f32,
    },

    /// Canvas position of a node changed.
    NodeMoved { id: String, position: Position },
}

// ---------------------------------------------------------------------------
// Shared types
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum NodeKind {
    /// Produces a texture from an external source (video, camera, etc.).
    Source,
    /// Transforms textures via a GLSL shader.
    ShaderPass,
    /// Combines multiple input textures.
    Mixer,
    /// Consumes the final texture (window / Syphon / Spout / encoder).
    Output,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum ParamValue {
    Float(f32),
    Int(i64),
    Bool(bool),
    Vec2([f32; 2]),
    Vec3([f32; 3]),
    Vec4([f32; 4]),
    Text(String),
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Position {
    pub x: f32,
    pub y: f32,
}

/// A full snapshot of the current graph as the frontend sees it.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct GraphState {
    pub nodes: Vec<NodeDescriptor>,
    pub edges: Vec<EdgeDescriptor>,
    pub compiled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeDescriptor {
    pub id: String,
    pub kind: NodeKind,
    pub label: String,
    pub position: Position,
    /// Current parameter surface.
    pub params: HashMap<String, ParamValue>,
    /// Shader source if applicable (None for source/output nodes with no GLSL).
    pub shader: Option<String>,
    pub input_ports: Vec<String>,
    pub output_ports: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EdgeDescriptor {
    pub from_node: String,
    pub from_port: String,
    pub to_node: String,
    pub to_port: String,
}

// ---------------------------------------------------------------------------
// Default port layouts per node kind
// ---------------------------------------------------------------------------

impl NodeKind {
    pub fn default_input_ports(&self) -> Vec<String> {
        match self {
            NodeKind::Source => vec![],
            NodeKind::ShaderPass => vec!["in0".to_string()],
            NodeKind::Mixer => vec!["in0".to_string(), "in1".to_string()],
            NodeKind::Output => vec!["in0".to_string()],
        }
    }

    pub fn default_output_ports(&self) -> Vec<String> {
        match self {
            NodeKind::Source => vec!["out".to_string()],
            NodeKind::ShaderPass => vec!["out".to_string()],
            NodeKind::Mixer => vec!["out".to_string()],
            NodeKind::Output => vec![],
        }
    }

    pub fn default_params(&self) -> HashMap<String, ParamValue> {
        let mut m = HashMap::new();
        match self {
            NodeKind::Mixer => {
                m.insert("mix".to_string(), ParamValue::Float(0.5));
            }
            NodeKind::ShaderPass => {
                m.insert("opacity".to_string(), ParamValue::Float(1.0));
            }
            _ => {}
        }
        m
    }
}
