/// scheng-bridge binary entry point
///
/// Run with:
///   cargo run -p scheng-bridge
///   SCHENG_BRIDGE_ADDR=0.0.0.0:7777 cargo run -p scheng-bridge
///
/// Or add as a dependency and call `BridgeServer::new(addr).run().await`
/// from your existing instrument binary.

use scheng_bridge::BridgeServer;
use std::net::SocketAddr;
use tracing_subscriber::EnvFilter;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // Logging: RUST_LOG=scheng_bridge=debug cargo run
    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| EnvFilter::new("scheng_bridge=info")),
        )
        .init();

    let addr: SocketAddr = std::env::var("SCHENG_BRIDGE_ADDR")
        .unwrap_or_else(|_| "127.0.0.1:7777".to_string())
        .parse()?;

    BridgeServer::new(addr).run().await
}
