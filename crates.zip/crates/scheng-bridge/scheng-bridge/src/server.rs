/// scheng-bridge — WebSocket server
///
/// Listens on a configurable address (default 127.0.0.1:7777).
/// Each connected client receives all broadcast events so multiple
/// frontends (or tools) can observe the same engine state simultaneously.

use crate::graph_manager::GraphManager;
use crate::protocol::{ClientMessage, EngineMessage};
use futures_util::{SinkExt, StreamExt};
use parking_lot::Mutex;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::broadcast;
use tokio_tungstenite::tungstenite::Message;
use tracing::{error, info, warn};

// ---------------------------------------------------------------------------
// Broadcaster — fan-out engine messages to all connected clients
// ---------------------------------------------------------------------------

pub type BroadcastTx = broadcast::Sender<String>;

// ---------------------------------------------------------------------------
// Server entry point
// ---------------------------------------------------------------------------

pub struct BridgeServer {
    pub addr: SocketAddr,
    pub manager: GraphManager,
}

impl BridgeServer {
    pub fn new(addr: SocketAddr) -> Self {
        BridgeServer {
            addr,
            manager: GraphManager::new(),
        }
    }

    pub async fn run(self) -> anyhow::Result<()> {
        let listener = TcpListener::bind(self.addr).await?;
        info!("scheng-bridge listening on ws://{}", self.addr);

        // Broadcast channel: engine → all connected clients
        let (broadcast_tx, _) = broadcast::channel::<String>(256);
        let manager = Arc::new(self.manager);

        loop {
            match listener.accept().await {
                Ok((stream, peer)) => {
                    info!("client connected: {peer}");
                    let tx = broadcast_tx.clone();
                    let mgr = manager.clone();
                    tokio::spawn(handle_connection(stream, peer, mgr, tx));
                }
                Err(e) => error!("accept error: {e}"),
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Per-connection handler
// ---------------------------------------------------------------------------

async fn handle_connection(
    stream: TcpStream,
    peer: SocketAddr,
    manager: Arc<GraphManager>,
    broadcast_tx: BroadcastTx,
) {
    let ws = match tokio_tungstenite::accept_async(stream).await {
        Ok(ws) => ws,
        Err(e) => {
            warn!("handshake failed from {peer}: {e}");
            return;
        }
    };

    let (mut ws_tx, mut ws_rx) = ws.split();
    let mut broadcast_rx = broadcast_tx.subscribe();

    // Send current state snapshot on connect so the frontend can hydrate
    let state = manager.snapshot();
    let snapshot_msg = serde_json::to_string(&EngineMessage::State(state)).unwrap();
    let _ = ws_tx.send(Message::Text(snapshot_msg.into())).await;

    loop {
        tokio::select! {
            // Inbound from this client
            msg = ws_rx.next() => {
                match msg {
                    Some(Ok(Message::Text(text))) => {
                        let responses = dispatch(&manager, &text);
                        for resp in responses {
                            let json = serde_json::to_string(&resp).unwrap();
                            // Broadcast to all clients so every connected
                            // frontend stays in sync
                            let _ = broadcast_tx.send(json);
                        }
                    }
                    Some(Ok(Message::Close(_))) | None => {
                        info!("client disconnected: {peer}");
                        break;
                    }
                    Some(Err(e)) => {
                        warn!("ws error from {peer}: {e}");
                        break;
                    }
                    _ => {}
                }
            }
            // Broadcast from other handlers / engine
            broadcast = broadcast_rx.recv() => {
                match broadcast {
                    Ok(json) => {
                        if ws_tx.send(Message::Text(json.into())).await.is_err() {
                            break;
                        }
                    }
                    Err(broadcast::error::RecvError::Lagged(n)) => {
                        warn!("client {peer} lagged {n} messages");
                    }
                    Err(_) => break,
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Command dispatch — translate ClientMessage → engine calls → EngineMessage
// ---------------------------------------------------------------------------

fn dispatch(manager: &GraphManager, raw: &str) -> Vec<EngineMessage> {
    let msg: ClientMessage = match serde_json::from_str(raw) {
        Ok(m) => m,
        Err(e) => {
            return vec![EngineMessage::Error {
                message: format!("parse error: {e}"),
                context: Some(raw.chars().take(120).collect()),
            }];
        }
    };

    match msg {
        // ── Graph topology ────────────────────────────────────────────────────
        ClientMessage::AddNode { id, kind, label, position } => {
            match manager.add_node(id, kind, label, position) {
                Ok(desc) => vec![EngineMessage::NodeAdded(desc)],
                Err(e) => vec![err(e)],
            }
        }

        ClientMessage::RemoveNode { id } => match manager.remove_node(&id) {
            Ok(()) => vec![EngineMessage::NodeRemoved { id }],
            Err(e) => vec![err(e)],
        },

        ClientMessage::Connect { from_node, from_port, to_node, to_port } => {
            match manager.connect(from_node, from_port, to_node, to_port) {
                Ok(edge) => vec![EngineMessage::EdgeAdded(edge)],
                Err(e) => vec![err(e)],
            }
        }

        ClientMessage::Disconnect { from_node, from_port, to_node, to_port } => {
            match manager.disconnect(&from_node, &from_port, &to_node, &to_port) {
                Ok(()) => vec![EngineMessage::EdgeRemoved { from_node, from_port, to_node, to_port }],
                Err(e) => vec![err(e)],
            }
        }

        // ── NodeProps ─────────────────────────────────────────────────────────
        ClientMessage::SetShader { node_id, glsl } => {
            match manager.set_shader(&node_id, glsl) {
                Ok(()) => vec![EngineMessage::ShaderUpdated { node_id }],
                Err(e) => vec![err(e)],
            }
        }

        ClientMessage::SetParam { node_id, param, value } => {
            match manager.set_param(&node_id, param.clone(), value.clone()) {
                Ok(()) => vec![EngineMessage::ParamUpdated { node_id, param, value }],
                Err(e) => vec![err(e)],
            }
        }

        ClientMessage::SetParams { node_id, params } => {
            match manager.set_params(&node_id, params) {
                Ok(()) => vec![
                    EngineMessage::Ok { ack: format!("params updated on {node_id}") },
                    EngineMessage::State(manager.snapshot()),
                ],
                Err(e) => vec![err(e)],
            }
        }

        // ── Compile ───────────────────────────────────────────────────────────
        ClientMessage::Compile => match manager.compile() {
            Ok((node_count, edge_count)) => vec![
                EngineMessage::Compiled { node_count, edge_count },
                EngineMessage::State(manager.snapshot()),
            ],
            Err(e) => vec![err(e)],
        },

        // ── State request ─────────────────────────────────────────────────────
        ClientMessage::GetState => vec![EngineMessage::State(manager.snapshot())],

        // ── Frame advance ─────────────────────────────────────────────────────
        ClientMessage::AdvanceFrame { width, height, time, frame } => {
            match manager.advance_frame(width, height, time, frame) {
                Ok(elapsed_ms) => vec![EngineMessage::FrameExecuted { frame, time, elapsed_ms }],
                Err(e) => vec![err(e)],
            }
        }

        // ── UI-only ───────────────────────────────────────────────────────────
        ClientMessage::MoveNode { id, position } => {
            match manager.move_node(&id, position.clone()) {
                Ok(()) => vec![EngineMessage::NodeMoved { id, position }],
                Err(e) => vec![err(e)],
            }
        }
    }
}

fn err(e: impl std::fmt::Display) -> EngineMessage {
    EngineMessage::Error {
        message: e.to_string(),
        context: None,
    }
}
