/// scheng-bridge — GraphManager
///
/// Owns the mutable graph state on behalf of the bridge. This is the
/// "instrument layer" boundary described in the SDK docs: it owns graph
/// topology (scheng-graph), NodeProps, and FrameCtx construction. The
/// WebSocket layer calls into this; the engine runtime is invoked here.
///
/// When you wire this to the real scheng crates, replace the stub types at
/// the bottom of this file with your actual imports from scheng-graph,
/// scheng-runtime, and scheng-runtime-glow.

use crate::protocol::*;
use parking_lot::RwLock;
use std::collections::HashMap;
use std::sync::Arc;
use tracing::{debug, info, warn};

// ---------------------------------------------------------------------------
// The manager — shareable across WebSocket handler tasks
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct GraphManager(Arc<RwLock<Inner>>);

impl GraphManager {
    pub fn new() -> Self {
        GraphManager(Arc::new(RwLock::new(Inner::default())))
    }

    // ── topology mutations ──────────────────────────────────────────────────

    pub fn add_node(
        &self,
        id: String,
        kind: NodeKind,
        label: String,
        position: Option<Position>,
    ) -> Result<NodeDescriptor, BridgeError> {
        let mut inner = self.0.write();
        if inner.nodes.contains_key(&id) {
            return Err(BridgeError::DuplicateNode(id));
        }

        let pos = position.unwrap_or_default();
        let descriptor = NodeDescriptor {
            id: id.clone(),
            input_ports: kind.default_input_ports(),
            output_ports: kind.default_output_ports(),
            params: kind.default_params(),
            shader: match &kind {
                NodeKind::ShaderPass => Some(default_passthrough_shader()),
                NodeKind::Mixer => Some(default_mixer_shader()),
                _ => None,
            },
            kind,
            label,
            position: pos,
        };

        inner.nodes.insert(id.clone(), descriptor.clone());
        inner.compiled = false; // topology changed — needs recompile
        info!("node added: {id}");
        Ok(descriptor)
    }

    pub fn remove_node(&self, id: &str) -> Result<(), BridgeError> {
        let mut inner = self.0.write();
        if !inner.nodes.contains_key(id) {
            return Err(BridgeError::NodeNotFound(id.to_string()));
        }
        inner.nodes.remove(id);
        inner.edges.retain(|e| e.from_node != id && e.to_node != id);
        inner.compiled = false;
        info!("node removed: {id}");
        Ok(())
    }

    pub fn connect(
        &self,
        from_node: String,
        from_port: String,
        to_node: String,
        to_port: String,
    ) -> Result<EdgeDescriptor, BridgeError> {
        let mut inner = self.0.write();

        // Validate nodes exist
        let from = inner
            .nodes
            .get(&from_node)
            .ok_or_else(|| BridgeError::NodeNotFound(from_node.clone()))?;
        if !from.output_ports.contains(&from_port) {
            return Err(BridgeError::PortNotFound(from_node.clone(), from_port.clone()));
        }
        let to = inner
            .nodes
            .get(&to_node)
            .ok_or_else(|| BridgeError::NodeNotFound(to_node.clone()))?;
        if !to.input_ports.contains(&to_port) {
            return Err(BridgeError::PortNotFound(to_node.clone(), to_port.clone()));
        }

        let edge = EdgeDescriptor {
            from_node,
            from_port,
            to_node,
            to_port,
        };

        // Prevent duplicate edges
        if inner.edges.contains(&edge) {
            return Err(BridgeError::DuplicateEdge);
        }

        inner.edges.push(edge.clone());
        inner.compiled = false;
        info!("edge added: {}.{} → {}.{}", edge.from_node, edge.from_port, edge.to_node, edge.to_port);
        Ok(edge)
    }

    pub fn disconnect(
        &self,
        from_node: &str,
        from_port: &str,
        to_node: &str,
        to_port: &str,
    ) -> Result<(), BridgeError> {
        let mut inner = self.0.write();
        let before = inner.edges.len();
        inner.edges.retain(|e| {
            !(e.from_node == from_node
                && e.from_port == from_port
                && e.to_node == to_node
                && e.to_port == to_port)
        });
        if inner.edges.len() == before {
            return Err(BridgeError::EdgeNotFound);
        }
        inner.compiled = false;
        Ok(())
    }

    // ── NodeProps mutations ─────────────────────────────────────────────────

    pub fn set_shader(&self, node_id: &str, glsl: String) -> Result<(), BridgeError> {
        let mut inner = self.0.write();
        let node = inner
            .nodes
            .get_mut(node_id)
            .ok_or_else(|| BridgeError::NodeNotFound(node_id.to_string()))?;
        node.shader = Some(glsl);
        // Shader change invalidates GPU program cache but NOT topology.
        // The runtime recompiles the shader lazily on next frame.
        debug!("shader updated on {node_id}");
        Ok(())
    }

    pub fn set_param(
        &self,
        node_id: &str,
        param: String,
        value: ParamValue,
    ) -> Result<(), BridgeError> {
        let mut inner = self.0.write();
        let node = inner
            .nodes
            .get_mut(node_id)
            .ok_or_else(|| BridgeError::NodeNotFound(node_id.to_string()))?;
        node.params.insert(param, value);
        Ok(())
    }

    pub fn set_params(
        &self,
        node_id: &str,
        params: HashMap<String, ParamValue>,
    ) -> Result<(), BridgeError> {
        let mut inner = self.0.write();
        let node = inner
            .nodes
            .get_mut(node_id)
            .ok_or_else(|| BridgeError::NodeNotFound(node_id.to_string()))?;
        node.params.extend(params);
        Ok(())
    }

    // ── Compile ──────────────────────────────────────────────────────────────

    /// Validate and compile the current topology into an execution plan.
    ///
    /// This is where you call `scheng_graph::Graph::compile()`.
    /// The stub here validates manually; replace with real engine call.
    pub fn compile(&self) -> Result<(usize, usize), BridgeError> {
        let mut inner = self.0.write();

        // Basic cycle detection is deferred to scheng-graph.
        // Here we just check that output nodes exist.
        let has_output = inner
            .nodes
            .values()
            .any(|n| matches!(n.kind, NodeKind::Output));
        if !has_output && !inner.nodes.is_empty() {
            warn!("compile: no output node found — graph may not render");
        }

        // ── Wire to real engine here ─────────────────────────────────────────
        // let mut graph = scheng_graph::Graph::new();
        // for (id, desc) in &inner.nodes { graph.add_node(id, &desc.kind.into()); }
        // for edge in &inner.edges { graph.connect(...); }
        // let plan = graph.compile()?;
        // inner.execution_plan = Some(plan);
        // ────────────────────────────────────────────────────────────────────

        let node_count = inner.nodes.len();
        let edge_count = inner.edges.len();
        inner.compiled = true;
        info!("compiled: {node_count} nodes, {edge_count} edges");
        Ok((node_count, edge_count))
    }

    // ── Frame advance ────────────────────────────────────────────────────────

    /// Drive the engine forward by one frame.
    ///
    /// Replace the stub timing with a real call to `execute_plan_outputs`.
    pub fn advance_frame(
        &self,
        width: u32,
        height: u32,
        time: f32,
        frame: u64,
    ) -> Result<f32, BridgeError> {
        let inner = self.0.read();

        if !inner.compiled {
            return Err(BridgeError::NotCompiled);
        }

        // ── Wire to real engine here ─────────────────────────────────────────
        // let ctx = scheng_runtime::FrameCtx { width, height, time, frame };
        // let elapsed = {
        //     let t0 = std::time::Instant::now();
        //     inner.runtime.execute_plan_outputs(&inner.execution_plan, &ctx, &inner.node_props)?;
        //     t0.elapsed().as_secs_f32() * 1000.0
        // };
        // ────────────────────────────────────────────────────────────────────

        // Stub: simulate 1–3 ms execution time
        let elapsed_ms = 2.1_f32;
        debug!("frame {frame} at t={time:.3}s ({width}×{height}) — {elapsed_ms:.1}ms");
        Ok(elapsed_ms)
    }

    // ── Move node (UI only) ──────────────────────────────────────────────────

    pub fn move_node(&self, id: &str, position: Position) -> Result<(), BridgeError> {
        let mut inner = self.0.write();
        let node = inner
            .nodes
            .get_mut(id)
            .ok_or_else(|| BridgeError::NodeNotFound(id.to_string()))?;
        node.position = position;
        Ok(())
    }

    // ── Snapshot ─────────────────────────────────────────────────────────────

    pub fn snapshot(&self) -> GraphState {
        let inner = self.0.read();
        GraphState {
            nodes: inner.nodes.values().cloned().collect(),
            edges: inner.edges.clone(),
            compiled: inner.compiled,
        }
    }
}

// ---------------------------------------------------------------------------
// Internal state
// ---------------------------------------------------------------------------

#[derive(Default)]
struct Inner {
    nodes: HashMap<String, NodeDescriptor>,
    edges: Vec<EdgeDescriptor>,
    compiled: bool,
    // execution_plan: Option<scheng_graph::ExecutionPlan>,  ← real engine field
    // runtime: scheng_runtime_glow::GlowRuntime,            ← real engine field
}

// ---------------------------------------------------------------------------
// Error type
// ---------------------------------------------------------------------------

#[derive(Debug, thiserror::Error)]
pub enum BridgeError {
    #[error("node not found: {0}")]
    NodeNotFound(String),
    #[error("node already exists: {0}")]
    DuplicateNode(String),
    #[error("port not found on node {0}: {1}")]
    PortNotFound(String, String),
    #[error("edge already exists")]
    DuplicateEdge,
    #[error("edge not found")]
    EdgeNotFound,
    #[error("graph has not been compiled — call Compile first")]
    NotCompiled,
    #[error("engine error: {0}")]
    Engine(String),
}

// Needed for EdgeDescriptor comparison
impl PartialEq for EdgeDescriptor {
    fn eq(&self, other: &Self) -> bool {
        self.from_node == other.from_node
            && self.from_port == other.from_port
            && self.to_node == other.to_node
            && self.to_port == other.to_port
    }
}

// ---------------------------------------------------------------------------
// Default shader templates
// ---------------------------------------------------------------------------

fn default_passthrough_shader() -> String {
    r#"#version 330 core
in vec2 vTexCoord;
uniform sampler2D uTex0;
uniform float uTime;
uniform vec2 uResolution;
out vec4 fragColor;

void main() {
    fragColor = texture(uTex0, vTexCoord);
}
"#
    .to_string()
}

fn default_mixer_shader() -> String {
    r#"#version 330 core
in vec2 vTexCoord;
uniform sampler2D uTex0;
uniform sampler2D uTex1;
uniform float mix;
uniform float uTime;
uniform vec2 uResolution;
out vec4 fragColor;

void main() {
    vec4 a = texture(uTex0, vTexCoord);
    vec4 b = texture(uTex1, vTexCoord);
    fragColor = mix(a, b, mix);
}
"#
    .to_string()
}
