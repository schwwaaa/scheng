/// scheng-bridge
///
/// A WebSocket bridge between the scheng engine and visual frontend editors.
///
/// # Architecture
///
/// ```text
///  Visual Frontend (browser / Electron)
///         │  JSON over WebSocket (ws://127.0.0.1:7777)
///  ┌──────▼──────────────────────────┐
///  │        BridgeServer             │  ← tokio async WebSocket layer
///  │        (server.rs)              │
///  └──────────────┬──────────────────┘
///                 │ calls into
///  ┌──────────────▼──────────────────┐
///  │        GraphManager             │  ← instrument layer: owns graph,
///  │        (graph_manager.rs)       │    NodeProps, FrameCtx semantics
///  └──────────────┬──────────────────┘
///                 │ ← wire to real crates here
///  ┌──────────────▼──────────────────┐
///  │  scheng-graph  │  scheng-runtime │  ← your Rust engine
///  │  scheng-runtime-glow            │
///  └─────────────────────────────────┘
/// ```
///
/// # Quick start
///
/// ```rust,no_run
/// use scheng_bridge::BridgeServer;
///
/// #[tokio::main]
/// async fn main() -> anyhow::Result<()> {
///     let addr = "127.0.0.1:7777".parse()?;
///     BridgeServer::new(addr).run().await
/// }
/// ```

pub mod graph_manager;
pub mod protocol;
pub mod server;

pub use graph_manager::GraphManager;
pub use server::BridgeServer;
